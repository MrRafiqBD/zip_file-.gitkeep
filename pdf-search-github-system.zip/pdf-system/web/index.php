<?php
/**
 * PDF ডেটাবেজ সার্চ সিস্টেম
 * বাংলা PDF কন্টেন্ট সার্চ — বিভাগ, জেলা, উপজেলা ভিত্তিক
 */

header('Content-Type: text/html; charset=UTF-8');
define('DB_PATH', __DIR__ . '/pdf_database.db');
define('RESULTS_PER_PAGE', 15);

// ── ডেটাবেজ কানেকশন ────────────────────────────────────────────
function getDB(): ?SQLite3 {
    if (!file_exists(DB_PATH)) return null;
    $db = new SQLite3(DB_PATH, SQLITE3_OPEN_READONLY);
    $db->exec("PRAGMA cache_size=5000");
    $db->exec("PRAGMA temp_store=MEMORY");
    return $db;
}

// ── সার্চ ফাংশন ─────────────────────────────────────────────────
function searchDocuments($db, $keyword, $division, $district, $upazila, $page = 1): array {
    $offset = ($page - 1) * RESULTS_PER_PAGE;
    $conditions = [];
    $params     = [];

    if ($keyword) {
        // FTS সার্চ চেষ্টা, না হলে LIKE
        try {
            $fts_stmt = $db->prepare("
                SELECT d.id, d.pdf_filename, d.zip_file,
                       d.division, d.district, d.upazila,
                       d.word_count, d.page_count,
                       snippet(documents_fts, 5, '<mark>', '</mark>', '…', 30) AS preview
                FROM documents_fts f
                JOIN documents d ON f.id = d.id
                WHERE documents_fts MATCH :kw
                " . buildLocationWhere($division, $district, $upazila, 'd.', true) . "
                ORDER BY rank
                LIMIT :lim OFFSET :off
            ");
            $fts_stmt->bindValue(':kw',  $keyword,               SQLITE3_TEXT);
            $fts_stmt->bindValue(':lim', RESULTS_PER_PAGE,       SQLITE3_INTEGER);
            $fts_stmt->bindValue(':off', $offset,                SQLITE3_INTEGER);
            bindLocationParams($fts_stmt, $division, $district, $upazila);
            $result = $fts_stmt->execute();
            $rows = fetchAll($result);
            if (!empty($rows)) return $rows;
        } catch (Exception $e) { /* FTS ব্যর্থ, LIKE-এ যাবে */ }

        $conditions[] = "content LIKE :kw";
        $params[':kw'] = "%{$keyword}%";
    }

    if ($division) { $conditions[] = "division = :div"; $params[':div'] = $division; }
    if ($district) { $conditions[] = "district = :dis"; $params[':dis'] = $district; }
    if ($upazila)  { $conditions[] = "upazila = :upa";  $params[':upa'] = $upazila; }

    $where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

    $stmt = $db->prepare("
        SELECT id, pdf_filename, zip_file, division, district, upazila,
               word_count, page_count,
               SUBSTR(content, 1, 300) AS preview
        FROM documents $where
        ORDER BY division, district, upazila, pdf_filename
        LIMIT :lim OFFSET :off
    ");
    foreach ($params as $k => $v) $stmt->bindValue($k, $v, SQLITE3_TEXT);
    $stmt->bindValue(':lim', RESULTS_PER_PAGE, SQLITE3_INTEGER);
    $stmt->bindValue(':off', $offset,          SQLITE3_INTEGER);

    return fetchAll($stmt->execute());
}

function countResults($db, $keyword, $division, $district, $upazila): int {
    $conditions = [];
    $params     = [];
    if ($keyword)  { $conditions[] = "content LIKE :kw";  $params[':kw']  = "%{$keyword}%"; }
    if ($division) { $conditions[] = "division = :div";   $params[':div'] = $division; }
    if ($district) { $conditions[] = "district = :dis";   $params[':dis'] = $district; }
    if ($upazila)  { $conditions[] = "upazila = :upa";    $params[':upa'] = $upazila; }

    $where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';
    $stmt  = $db->prepare("SELECT COUNT(*) as c FROM documents $where");
    foreach ($params as $k => $v) $stmt->bindValue($k, $v, SQLITE3_TEXT);
    $row = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    return (int)($row['c'] ?? 0);
}

function getStats($db): array {
    $stats = [];
    $queries = [
        'total'     => "SELECT COUNT(*) as c FROM documents",
        'divisions' => "SELECT COUNT(DISTINCT division) as c FROM documents WHERE division IS NOT NULL",
        'districts' => "SELECT COUNT(DISTINCT district) as c FROM documents WHERE district IS NOT NULL",
        'upazilas'  => "SELECT COUNT(DISTINCT upazila) as c FROM documents WHERE upazila IS NOT NULL",
    ];
    foreach ($queries as $key => $sql) {
        $row = $db->querySingle($sql, true);
        $stats[$key] = (int)($row['c'] ?? 0);
    }
    return $stats;
}

function getDivisions($db): array {
    $res  = $db->query("SELECT DISTINCT division FROM documents WHERE division IS NOT NULL ORDER BY division");
    $list = [];
    while ($row = $res->fetchArray(SQLITE3_ASSOC)) $list[] = $row['division'];
    return $list;
}

function getDistricts($db, $division): array {
    $stmt = $db->prepare("SELECT DISTINCT district FROM documents WHERE division=:d AND district IS NOT NULL ORDER BY district");
    $stmt->bindValue(':d', $division, SQLITE3_TEXT);
    $res  = $stmt->execute();
    $list = [];
    while ($row = $res->fetchArray(SQLITE3_ASSOC)) $list[] = $row['district'];
    return $list;
}

function getUpazilas($db, $district): array {
    $stmt = $db->prepare("SELECT DISTINCT upazila FROM documents WHERE district=:d AND upazila IS NOT NULL ORDER BY upazila");
    $stmt->bindValue(':d', $district, SQLITE3_TEXT);
    $res  = $stmt->execute();
    $list = [];
    while ($row = $res->fetchArray(SQLITE3_ASSOC)) $list[] = $row['upazila'];
    return $list;
}

function getDocument($db, $id): ?array {
    $stmt = $db->prepare("SELECT * FROM documents WHERE id=:id");
    $stmt->bindValue(':id', (int)$id, SQLITE3_INTEGER);
    $row = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    return $row ?: null;
}

// ── হেল্পার ────────────────────────────────────────────────────
function fetchAll($result): array {
    $rows = [];
    if (!$result) return $rows;
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) $rows[] = $row;
    return $rows;
}

function buildLocationWhere($div, $dis, $upa, $prefix = '', $andPrefix = false): string {
    $parts = [];
    if ($div) $parts[] = "{$prefix}division = :div";
    if ($dis) $parts[] = "{$prefix}district = :dis";
    if ($upa) $parts[] = "{$prefix}upazila  = :upa";
    if (!$parts) return '';
    return ($andPrefix ? 'AND ' : 'WHERE ') . implode(' AND ', $parts);
}

function bindLocationParams($stmt, $div, $dis, $upa): void {
    if ($div) $stmt->bindValue(':div', $div, SQLITE3_TEXT);
    if ($dis) $stmt->bindValue(':dis', $dis, SQLITE3_TEXT);
    if ($upa) $stmt->bindValue(':upa', $upa, SQLITE3_TEXT);
}

function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// ── ইনপুট ──────────────────────────────────────────────────────
$db       = getDB();
$keyword  = trim($_GET['q']        ?? '');
$division = trim($_GET['division'] ?? '');
$district = trim($_GET['district'] ?? '');
$upazila  = trim($_GET['upazila']  ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$view_id  = isset($_GET['view']) ? (int)$_GET['view'] : null;

// AJAX: জেলা/উপজেলা ড্রপডাউন
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json; charset=UTF-8');
    if ($_GET['ajax'] === 'districts' && $division && $db) {
        echo json_encode(getDistricts($db, $division));
    } elseif ($_GET['ajax'] === 'upazilas' && $district && $db) {
        echo json_encode(getUpazilas($db, $district));
    } else {
        echo '[]';
    }
    exit;
}

$results    = [];
$total      = 0;
$stats      = $db ? getStats($db) : [];
$divisions  = $db ? getDivisions($db) : [];
$doc        = ($view_id && $db) ? getDocument($db, $view_id) : null;
$searching  = $keyword || $division || $district || $upazila;

if ($searching && $db) {
    $results = searchDocuments($db, $keyword, $division, $district, $upazila, $page);
    $total   = countResults($db, $keyword, $division, $district, $upazila);
}

$total_pages = $total > 0 ? (int)ceil($total / RESULTS_PER_PAGE) : 0;
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PDF ডেটাবেজ সার্চ</title>
<style>
  /* ── টোকেন ── */
  :root {
    --green:   #1a7a4a;
    --green-d: #145f39;
    --green-l: #e8f5ee;
    --red:     #c0392b;
    --gold:    #f0a500;
    --ink:     #1c1c1c;
    --muted:   #5a6472;
    --border:  #d4dde6;
    --bg:      #f5f7fa;
    --white:   #ffffff;
    --radius:  8px;
    --shadow:  0 2px 12px rgba(0,0,0,.08);
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'Kalpurush', 'SolaimanLipi', 'Noto Sans Bengali', system-ui, sans-serif;
    background: var(--bg);
    color: var(--ink);
    min-height: 100vh;
  }

  /* ── হেডার ── */
  header {
    background: linear-gradient(135deg, var(--green) 0%, var(--green-d) 100%);
    color: var(--white);
    padding: 0 24px;
  }
  .header-inner {
    max-width: 1100px;
    margin: auto;
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 18px 0;
  }
  .logo {
    width: 44px; height: 44px;
    background: rgba(255,255,255,.15);
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 22px;
  }
  header h1 { font-size: 1.4rem; font-weight: 700; }
  header p  { font-size: .85rem; opacity: .8; margin-top: 2px; }

  /* ── স্ট্যাটস বার ── */
  .stats-bar {
    background: var(--white);
    border-bottom: 1px solid var(--border);
  }
  .stats-inner {
    max-width: 1100px;
    margin: auto;
    display: flex;
    gap: 32px;
    padding: 12px 24px;
    flex-wrap: wrap;
  }
  .stat { display: flex; align-items: center; gap: 8px; }
  .stat-num { font-size: 1.2rem; font-weight: 700; color: var(--green); }
  .stat-lbl { font-size: .8rem; color: var(--muted); }

  /* ── মূল লেআউট ── */
  .main { max-width: 1100px; margin: 32px auto; padding: 0 24px; }

  /* ── সার্চ বক্স ── */
  .search-card {
    background: var(--white);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    padding: 28px;
    margin-bottom: 28px;
  }
  .search-card h2 { font-size: 1rem; color: var(--muted); margin-bottom: 16px; font-weight: 500; }

  .keyword-row {
    display: flex; gap: 10px; margin-bottom: 16px;
  }
  .keyword-row input {
    flex: 1;
    padding: 12px 16px;
    border: 2px solid var(--border);
    border-radius: var(--radius);
    font-size: 1rem;
    font-family: inherit;
    outline: none;
    transition: border .2s;
  }
  .keyword-row input:focus { border-color: var(--green); }

  .filter-row {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-bottom: 16px;
  }
  @media(max-width: 600px) { .filter-row { grid-template-columns: 1fr; } }

  select {
    width: 100%;
    padding: 10px 14px;
    border: 2px solid var(--border);
    border-radius: var(--radius);
    font-size: .95rem;
    font-family: inherit;
    background: var(--white);
    color: var(--ink);
    outline: none;
    cursor: pointer;
    transition: border .2s;
  }
  select:focus { border-color: var(--green); }

  .btn {
    padding: 12px 28px;
    border: none;
    border-radius: var(--radius);
    font-size: 1rem;
    font-family: inherit;
    font-weight: 600;
    cursor: pointer;
    transition: background .2s, transform .1s;
  }
  .btn:active { transform: scale(.98); }
  .btn-primary { background: var(--green); color: var(--white); }
  .btn-primary:hover { background: var(--green-d); }
  .btn-clear { background: var(--bg); color: var(--muted); border: 2px solid var(--border); }
  .btn-clear:hover { background: var(--border); }

  .action-row { display: flex; gap: 10px; }

  /* ── ফলাফল ── */
  .result-meta {
    color: var(--muted);
    font-size: .9rem;
    margin-bottom: 16px;
  }
  .result-meta strong { color: var(--green); }

  .result-card {
    background: var(--white);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    padding: 20px 24px;
    margin-bottom: 14px;
    border-left: 4px solid var(--green);
    transition: box-shadow .2s;
  }
  .result-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,.12); }

  .result-title {
    font-size: 1.05rem;
    font-weight: 700;
    color: var(--green);
    margin-bottom: 6px;
  }
  .result-title a { color: inherit; text-decoration: none; }
  .result-title a:hover { text-decoration: underline; }

  .result-tags {
    display: flex; flex-wrap: wrap; gap: 6px;
    margin-bottom: 10px;
  }
  .tag {
    background: var(--green-l);
    color: var(--green-d);
    padding: 3px 10px;
    border-radius: 20px;
    font-size: .8rem;
    font-weight: 500;
  }
  .tag-zip {
    background: #fff3e0;
    color: #e65100;
  }

  .result-preview {
    font-size: .9rem;
    color: var(--muted);
    line-height: 1.7;
  }
  .result-preview mark {
    background: #fff176;
    color: var(--ink);
    padding: 0 2px;
    border-radius: 2px;
  }

  .result-footer {
    margin-top: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: .82rem;
    color: var(--muted);
  }

  /* ── পেজিনেশন ── */
  .pagination {
    display: flex; gap: 6px; justify-content: center;
    margin-top: 28px; flex-wrap: wrap;
  }
  .pagination a, .pagination span {
    display: inline-flex; align-items: center; justify-content: center;
    width: 40px; height: 40px;
    border-radius: var(--radius);
    font-size: .9rem; text-decoration: none;
    border: 2px solid var(--border);
    color: var(--ink);
    transition: all .2s;
  }
  .pagination a:hover { border-color: var(--green); color: var(--green); }
  .pagination .active {
    background: var(--green); color: var(--white);
    border-color: var(--green);
  }

  /* ── খালি অবস্থা ── */
  .empty {
    text-align: center; padding: 60px 20px;
    color: var(--muted);
  }
  .empty .icon { font-size: 48px; margin-bottom: 12px; }
  .empty h3 { font-size: 1.1rem; margin-bottom: 6px; color: var(--ink); }

  /* ── ডকুমেন্ট ভিউ ── */
  .doc-view {
    background: var(--white);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    padding: 32px;
  }
  .doc-view h2 { font-size: 1.2rem; margin-bottom: 16px; }
  .doc-content {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 24px;
    white-space: pre-wrap;
    line-height: 2;
    font-size: .95rem;
    max-height: 600px;
    overflow-y: auto;
  }

  /* ── ডেটাবেজ নেই ── */
  .no-db {
    background: #fff8e1;
    border: 2px dashed var(--gold);
    border-radius: var(--radius);
    padding: 40px;
    text-align: center;
  }
  .no-db .icon { font-size: 48px; }
  .no-db h2 { color: var(--ink); margin: 12px 0 8px; }
  .no-db p { color: var(--muted); margin-bottom: 4px; }
</style>
</head>
<body>

<!-- ── হেডার ── -->
<header>
  <div class="header-inner">
    <div class="logo">📄</div>
    <div>
      <h1>PDF ডেটাবেজ সার্চ</h1>
      <p>বিভাগ · জেলা · উপজেলা ভিত্তিক বাংলা দলিল অনুসন্ধান</p>
    </div>
  </div>
</header>

<!-- ── স্ট্যাটস ── -->
<?php if ($db && $stats): ?>
<div class="stats-bar">
  <div class="stats-inner">
    <div class="stat">
      <span class="stat-num"><?= number_format($stats['total']) ?></span>
      <span class="stat-lbl">মোট ডকুমেন্ট</span>
    </div>
    <div class="stat">
      <span class="stat-num"><?= $stats['divisions'] ?></span>
      <span class="stat-lbl">বিভাগ</span>
    </div>
    <div class="stat">
      <span class="stat-num"><?= $stats['districts'] ?></span>
      <span class="stat-lbl">জেলা</span>
    </div>
    <div class="stat">
      <span class="stat-num"><?= $stats['upazilas'] ?></span>
      <span class="stat-lbl">উপজেলা</span>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="main">

<?php if (!$db): ?>
<!-- ── ডেটাবেজ নেই ── -->
<div class="no-db">
  <div class="icon">⚠️</div>
  <h2>ডেটাবেজ পাওয়া যায়নি</h2>
  <p>GitHub Actions চালান এবং <code>pdf_database.db</code> এই ফোল্ডারে আপলোড করুন।</p>
  <p style="margin-top:8px;font-size:.85rem;color:#999">প্রত্যাশিত পাথ: <code><?= DB_PATH ?></code></p>
</div>

<?php elseif ($doc): ?>
<!-- ── একটি ডকুমেন্ট দেখানো ── -->
<div style="margin-bottom:16px">
  <a href="?" style="color:var(--green);text-decoration:none">← সার্চে ফিরুন</a>
</div>
<div class="doc-view">
  <h2><?= h($doc['pdf_filename']) ?></h2>
  <div class="result-tags">
    <?php if ($doc['division']): ?><span class="tag"><?= h($doc['division']) ?></span><?php endif; ?>
    <?php if ($doc['district']): ?><span class="tag"><?= h($doc['district']) ?></span><?php endif; ?>
    <?php if ($doc['upazila']):  ?><span class="tag"><?= h($doc['upazila']) ?></span><?php endif; ?>
    <span class="tag tag-zip"><?= h($doc['zip_file']) ?></span>
  </div>
  <p style="color:var(--muted);font-size:.85rem;margin-bottom:16px">
    📄 পৃষ্ঠা: <?= $doc['page_count'] ?> &nbsp;|&nbsp;
    📝 শব্দ: <?= number_format($doc['word_count']) ?> &nbsp;|&nbsp;
    🕒 <?= substr($doc['extraction_date'], 0, 10) ?>
  </p>
  <div class="doc-content"><?= h($doc['content']) ?></div>
</div>

<?php else: ?>
<!-- ── সার্চ ফর্ম ── -->
<div class="search-card">
  <h2>🔍 অনুসন্ধান করুন</h2>
  <form method="GET" action="" id="searchForm">
    <div class="keyword-row">
      <input type="text" name="q" placeholder="যেকোনো শব্দ বা বাক্য লিখুন…"
             value="<?= h($keyword) ?>" autofocus>
    </div>
    <div class="filter-row">
      <select name="division" id="sel-division" onchange="loadDistricts(this.value)">
        <option value="">— সব বিভাগ —</option>
        <?php foreach ($divisions as $div): ?>
          <option value="<?= h($div) ?>" <?= $division === $div ? 'selected' : '' ?>><?= h($div) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="district" id="sel-district" onchange="loadUpazilas(this.value)">
        <option value="">— সব জেলা —</option>
        <?php if ($district): ?>
          <option value="<?= h($district) ?>" selected><?= h($district) ?></option>
        <?php endif; ?>
      </select>
      <select name="upazila" id="sel-upazila">
        <option value="">— সব উপজেলা —</option>
        <?php if ($upazila): ?>
          <option value="<?= h($upazila) ?>" selected><?= h($upazila) ?></option>
        <?php endif; ?>
      </select>
    </div>
    <div class="action-row">
      <button type="submit" class="btn btn-primary">🔍 সার্চ করুন</button>
      <a href="?" class="btn btn-clear">✕ পরিষ্কার</a>
    </div>
  </form>
</div>

<!-- ── ফলাফল ── -->
<?php if ($searching): ?>
  <p class="result-meta">
    <strong><?= number_format($total) ?></strong> টি ফলাফল পাওয়া গেছে
    <?php if ($keyword): ?> "<strong><?= h($keyword) ?></strong>" এর জন্য<?php endif; ?>
    <?php if ($division || $district || $upazila): ?>
      —
      <?= $division ? h($division) : '' ?>
      <?= $district ? ' › ' . h($district) : '' ?>
      <?= $upazila  ? ' › ' . h($upazila)  : '' ?>
    <?php endif; ?>
    <?php if ($total_pages > 1): ?> (পৃষ্ঠা <?= $page ?>/<?= $total_pages ?>)<?php endif; ?>
  </p>

  <?php if (empty($results)): ?>
    <div class="empty">
      <div class="icon">🔎</div>
      <h3>কোনো ফলাফল পাওয়া যায়নি</h3>
      <p>ভিন্ন শব্দ বা ফিল্টার দিয়ে চেষ্টা করুন।</p>
    </div>
  <?php else: ?>
    <?php foreach ($results as $row): ?>
    <div class="result-card">
      <div class="result-title">
        <a href="?view=<?= $row['id'] ?>"><?= h($row['pdf_filename']) ?></a>
      </div>
      <div class="result-tags">
        <?php if ($row['division']): ?><span class="tag"><?= h($row['division']) ?></span><?php endif; ?>
        <?php if ($row['district']): ?><span class="tag"><?= h($row['district']) ?></span><?php endif; ?>
        <?php if ($row['upazila']):  ?><span class="tag"><?= h($row['upazila']) ?></span><?php endif; ?>
        <span class="tag tag-zip"><?= h($row['zip_file']) ?></span>
      </div>
      <?php if ($row['preview']): ?>
        <div class="result-preview"><?= $row['preview'] ?></div>
      <?php endif; ?>
      <div class="result-footer">
        <span>📄 <?= $row['page_count'] ?> পৃষ্ঠা &nbsp;|&nbsp; 📝 <?= number_format($row['word_count']) ?> শব্দ</span>
        <a href="?view=<?= $row['id'] ?>" style="color:var(--green);text-decoration:none;font-weight:600">পড়ুন →</a>
      </div>
    </div>
    <?php endforeach; ?>

    <!-- পেজিনেশন -->
    <?php if ($total_pages > 1): ?>
    <div class="pagination">
      <?php
      $base = '?q=' . urlencode($keyword)
            . '&division=' . urlencode($division)
            . '&district=' . urlencode($district)
            . '&upazila='  . urlencode($upazila);

      if ($page > 1) echo "<a href='{$base}&page=" . ($page-1) . "'>‹</a>";

      $start = max(1, $page - 2);
      $end   = min($total_pages, $page + 2);
      for ($p = $start; $p <= $end; $p++):
        if ($p === $page): ?>
          <span class="active"><?= $p ?></span>
        <?php else: ?>
          <a href="<?= $base ?>&page=<?= $p ?>"><?= $p ?></a>
        <?php endif;
      endfor;

      if ($page < $total_pages) echo "<a href='{$base}&page=" . ($page+1) . "'>›</a>";
      ?>
    </div>
    <?php endif; ?>
  <?php endif; ?>

<?php else: ?>
  <!-- সার্চ করা হয়নি — ওয়েলকাম -->
  <div class="empty" style="padding:40px 0">
    <div class="icon">🏛️</div>
    <h3>সার্চ শুরু করুন</h3>
    <p>কীওয়ার্ড লিখুন অথবা বিভাগ/জেলা/উপজেলা বেছে নিন।</p>
  </div>
<?php endif; ?>
<?php endif; ?>

</div><!-- .main -->

<script>
// ── AJAX ড্রপডাউন ─────────────────────────────────────────
async function loadDistricts(division) {
  const dis = document.getElementById('sel-district');
  const upa = document.getElementById('sel-upazila');
  dis.innerHTML = '<option value="">— লোড হচ্ছে… —</option>';
  upa.innerHTML = '<option value="">— সব উপজেলা —</option>';

  if (!division) { dis.innerHTML = '<option value="">— সব জেলা —</option>'; return; }

  const res  = await fetch('?ajax=districts&division=' + encodeURIComponent(division));
  const data = await res.json();

  dis.innerHTML = '<option value="">— সব জেলা —</option>';
  data.forEach(d => {
    const o = document.createElement('option');
    o.value = d; o.textContent = d;
    dis.appendChild(o);
  });
}

async function loadUpazilas(district) {
  const upa = document.getElementById('sel-upazila');
  upa.innerHTML = '<option value="">— লোড হচ্ছে… —</option>';

  if (!district) { upa.innerHTML = '<option value="">— সব উপজেলা —</option>'; return; }

  const res  = await fetch('?ajax=upazilas&district=' + encodeURIComponent(district));
  const data = await res.json();

  upa.innerHTML = '<option value="">— সব উপজেলা —</option>';
  data.forEach(u => {
    const o = document.createElement('option');
    o.value = u; o.textContent = u;
    upa.appendChild(o);
  });
}

// পেজ লোডে আগের ভ্যালু থাকলে জেলা/উপজেলা লোড করো
window.addEventListener('DOMContentLoaded', () => {
  const savedDiv = '<?= h($division) ?>';
  const savedDis = '<?= h($district) ?>';
  const savedUpa = '<?= h($upazila)  ?>';

  if (savedDiv) {
    loadDistricts(savedDiv).then(() => {
      if (savedDis) {
        document.getElementById('sel-district').value = savedDis;
        loadUpazilas(savedDis).then(() => {
          if (savedUpa) document.getElementById('sel-upazila').value = savedUpa;
        });
      }
    });
  }
});
</script>
</body>
</html>
