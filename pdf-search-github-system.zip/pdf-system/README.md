# PDF ডেটাবেজ সার্চ সিস্টেম
### GitHub Actions + cPanel (PHP Only)

---

## সিস্টেম কীভাবে কাজ করে

```
আপনার PC
    ↓ ZIP ফাইল GitHub-এ push করুন
GitHub Actions (ফ্রি)
    ↓ Python দিয়ে PDF প্রসেস করে
    ↓ SQLite ডেটাবেজ তৈরি করে
    ↓ FTP দিয়ে cPanel-এ আপলোড করে
cPanel Hosting
    ↓ PHP ওয়েব ইন্টারফেস দেখায়
আপনার ওয়েবসাইট — ব্রাউজার থেকে সার্চ!
```

---

## ধাপ ১ — GitHub Repository তৈরি

1. https://github.com/new — নতুন repository তৈরি করুন
2. নাম দিন: `pdf-search-system`
3. **Private** রাখুন (ডেটা সুরক্ষার জন্য)
4. এই ফোল্ডারের সব ফাইল ওই repository-তে push করুন:

```bash
git init
git add .
git commit -m "Initial setup"
git remote add origin https://github.com/YOUR_USERNAME/pdf-search-system.git
git push -u origin main
```

---

## ধাপ ২ — GitHub Secrets সেট করুন

GitHub repository → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

এই ৪টি Secret যোগ করুন:

| Secret নাম | মান | কোথায় পাবেন |
|---|---|---|
| `FTP_HOST` | `ftp.yourdomain.com` | cPanel → FTP Accounts |
| `FTP_USERNAME` | `user@yourdomain.com` | cPanel → FTP Accounts |
| `FTP_PASSWORD` | আপনার FTP পাসওয়ার্ড | cPanel → FTP Accounts |
| `FTP_SERVER_DIR` | `/public_html/pdf-search/` | যেখানে রাখতে চান |

### cPanel থেকে FTP তথ্য বের করার উপায়:
1. cPanel → **FTP Accounts** → **Add FTP Account**
2. নতুন FTP User তৈরি করুন (যেমন: `pdfuser`)
3. Directory: `/public_html/pdf-search`
4. তথ্যগুলো GitHub Secrets-এ দিন

---

## ধাপ ৩ — ZIP ফাইল আপলোড করুন

Repository-তে `zip_files/` ফোল্ডারে আপনার ZIP ফাইলগুলো রাখুন:

```
pdf-search-system/
├── zip_files/
│   ├── ঢাকা_বিভাগ.zip        ← এখানে রাখুন
│   ├── চট্টগ্রাম_বিভাগ.zip
│   └── রাজশাহী_বিভাগ.zip
├── scripts/
│   └── pdf_extractor.py
├── web/
│   └── index.php
└── .github/workflows/
    └── process-pdfs.yml
```

ZIP push করলেই GitHub Actions স্বয়ংক্রিয়ভাবে চলবে!

---

## ধাপ ৪ — cPanel-এ ফোল্ডার তৈরি করুন

1. cPanel → **File Manager**
2. `public_html` এর ভেতরে `pdf-search` ফোল্ডার তৈরি করুন
3. **প্রথমবার** `web/index.php` ম্যানুয়ালি আপলোড করুন
   (পরবর্তীতে GitHub Actions স্বয়ংক্রিয়ভাবে আপডেট করবে)

---

## ধাপ ৫ — GitHub Actions চালু দেখুন

1. GitHub → **Actions** ট্যাবে যান
2. "PDF প্রসেস ও cPanel আপলোড" workflow দেখবেন
3. সবুজ টিক ✅ মানে সফল
4. আপনার সাইটে যান: `https://yourdomain.com/pdf-search/`

---

## ফাইলের নামকরণ (গুরুত্বপূর্ণ)

PDF ফাইলের নামে বিভাগ/জেলা/উপজেলার নাম রাখলে স্বয়ংক্রিয়ভাবে সনাক্ত হবে:

```
✓ ঢাকা_গাজীপুর_সাভার_001.pdf
✓ চট্টগ্রাম_কক্সবাজার_রামু_জমির_দলিল.pdf
✗ scan001.pdf  (লোকেশন ধরতে পারবে না)
```

---

## বড় ZIP ফাইলের জন্য

GitHub-এ ১০০MB এর বেশি ফাইল সরাসরি push করা যায় না।
**Git LFS** ব্যবহার করুন:

```bash
git lfs install
git lfs track "*.zip"
git add .gitattributes
git add zip_files/বড়_ফাইল.zip
git commit -m "Add large zip"
git push
```

---

## সমস্যা হলে

**Actions ফেল করলে:**
- GitHub → Actions → ক্লিক করে লগ দেখুন
- FTP তথ্য সঠিক কিনা চেক করুন

**সাইটে ডেটাবেজ না দেখালে:**
- cPanel → File Manager → `pdf-search/pdf_database.db` আছে কিনা দেখুন

**বাংলা ভেঙে গেলে:**
- PDF টি স্ক্যান করা (ছবি) হতে পারে — OCR দরকার হবে
