#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF থেকে বাংলা টেক্সট এক্সট্র্যাক্ট করে SQLite ডেটাবেজে সংরক্ষণ করার সিস্টেম
বিভাগ → জেলা → উপজেলা ভিত্তিক সংগঠিত ডেটাবেজ
"""

import os
import re
import zipfile
import sqlite3
import logging
from pathlib import Path
from datetime import datetime

# প্রয়োজনীয় লাইব্রেরি ইমপোর্ট
try:
    import pdfplumber
except ImportError:
    print("pdfplumber ইনস্টল করুন: pip install pdfplumber")
    raise

try:
    import fitz  # PyMuPDF - বাংলা টেক্সটের জন্য সবচেয়ে ভালো
except ImportError:
    print("PyMuPDF ইনস্টল করুন: pip install PyMuPDF")
    raise

# ========== লগিং সেটআপ ==========
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler("extraction.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# ========== বাংলাদেশের বিভাগ/জেলা/উপজেলা তালিকা ==========
BANGLADESH_LOCATIONS = {
    "ঢাকা": {
        "ঢাকা": ["সাভার", "ধামরাই", "কেরানীগঞ্জ", "নবাবগঞ্জ", "দোহার", "ঢাকা সদর"],
        "গাজীপুর": ["গাজীপুর সদর", "কালীগঞ্জ", "কাপাসিয়া", "শ্রীপুর", "টঙ্গী"],
        "নারায়ণগঞ্জ": ["নারায়ণগঞ্জ সদর", "আড়াইহাজার", "বন্দর", "রূপগঞ্জ", "সোনারগাঁও"],
        "মানিকগঞ্জ": ["মানিকগঞ্জ সদর", "ঘিওর", "দৌলতপুর", "হরিরামপুর", "শিবালয়", "সিঙ্গাইর"],
        "মুন্সিগঞ্জ": ["মুন্সিগঞ্জ সদর", "গজারিয়া", "লৌহজং", "শ্রীনগর", "সিরাজদিখান", "টঙ্গীবাড়ী"],
        "কিশোরগঞ্জ": ["কিশোরগঞ্জ সদর", "ভৈরব", "হোসেনপুর", "ইটনা", "কটিয়াদী", "করিমগঞ্জ"],
        "টাঙ্গাইল": ["টাঙ্গাইল সদর", "বাসাইল", "ভূঞাপুর", "দেলদুয়ার", "ঘাটাইল", "গোপালপুর"],
        "ফরিদপুর": ["ফরিদপুর সদর", "আলফাডাঙ্গা", "বোয়ালমারী", "চরভদ্রাসন", "মধুখালী"],
    },
    "চট্টগ্রাম": {
        "চট্টগ্রাম": ["চট্টগ্রাম সদর", "আনোয়ারা", "বাঁশখালী", "বোয়ালখালী", "চন্দনাইশ", "ফটিকছড়ি"],
        "কক্সবাজার": ["কক্সবাজার সদর", "চকরিয়া", "কুতুবদিয়া", "মহেশখালী", "রামু", "টেকনাফ", "উখিয়া"],
        "কুমিল্লা": ["কুমিল্লা সদর", "বরুড়া", "ব্রাহ্মণপাড়া", "বুড়িচং", "চান্দিনা", "দেবিদ্বার"],
        "ফেনী": ["ফেনী সদর", "ছাগলনাইয়া", "দাগনভূঞা", "ফুলগাজী", "পরশুরাম", "সোনাগাজী"],
        "নোয়াখালী": ["নোয়াখালী সদর", "বেগমগঞ্জ", "চাটখিল", "কোম্পানীগঞ্জ", "হাতিয়া", "সেনবাগ"],
        "সিলেট": ["সিলেট সদর", "বালাগঞ্জ", "বিয়ানীবাজার", "বিশ্বনাথ", "কোম্পানীগঞ্জ", "ফেঞ্চুগঞ্জ"],
        "রাঙামাটি": ["রাঙামাটি সদর", "বাঘাইছড়ি", "বরকল", "কাউখালী", "কাপ্তাই", "লংগদু"],
        "বান্দরবান": ["বান্দরবান সদর", "আলীকদম", "লামা", "নাইক্ষ্যংছড়ি", "রোয়াংছড়ি", "রুমা", "থানচি"],
    },
    "রাজশাহী": {
        "রাজশাহী": ["রাজশাহী সদর", "বাগমারা", "চারঘাট", "দুর্গাপুর", "গোদাগাড়ী", "মোহনপুর"],
        "বগুড়া": ["বগুড়া সদর", "আদমদীঘি", "ধুনট", "দুপচাঁচিয়া", "গাবতলী", "কাহালু", "নন্দীগ্রাম"],
        "নাটোর": ["নাটোর সদর", "বাগাতিপাড়া", "বড়াইগ্রাম", "গুরুদাসপুর", "লালপুর", "সিংড়া"],
        "পাবনা": ["পাবনা সদর", "আটঘরিয়া", "বেড়া", "ভাঙ্গুড়া", "চাটমোহর", "ঈশ্বরদী", "সাঁথিয়া"],
        "নওগাঁ": ["নওগাঁ সদর", "আত্রাই", "বদলগাছী", "ধামইরহাট", "মান্দা", "মহাদেবপুর", "নিয়ামতপুর"],
        "চাঁপাইনবাবগঞ্জ": ["চাঁপাইনবাবগঞ্জ সদর", "ভোলাহাট", "গোমস্তাপুর", "নাচোল", "শিবগঞ্জ"],
    },
    "খুলনা": {
        "খুলনা": ["খুলনা সদর", "বটিয়াঘাটা", "দাকোপ", "ডুমুরিয়া", "দিঘলিয়া", "কয়রা", "পাইকগাছা"],
        "বাগেরহাট": ["বাগেরহাট সদর", "চিতলমারী", "ফকিরহাট", "কচুয়া", "মংলা", "মোরেলগঞ্জ", "মোল্লাহাট"],
        "সাতক্ষীরা": ["সাতক্ষীরা সদর", "আশাশুনি", "দেবহাটা", "কালিগঞ্জ", "কলারোয়া", "শ্যামনগর", "তালা"],
        "যশোর": ["যশোর সদর", "অভয়নগর", "বাঘারপাড়া", "চৌগাছা", "ঝিকরগাছা", "কেশবপুর", "মণিরামপুর"],
        "কুষ্টিয়া": ["কুষ্টিয়া সদর", "ভেড়ামারা", "দৌলতপুর", "খোকসা", "কুমারখালী", "মিরপুর"],
    },
    "বরিশাল": {
        "বরিশাল": ["বরিশাল সদর", "আগৈলঝাড়া", "বাবুগঞ্জ", "বাকেরগঞ্জ", "বানারীপাড়া", "গৌরনদী", "হিজলা"],
        "ভোলা": ["ভোলা সদর", "বোরহানউদ্দিন", "চরফ্যাশন", "দৌলতখান", "লালমোহন", "মনপুরা", "তজুমদ্দিন"],
        "পটুয়াখালী": ["পটুয়াখালী সদর", "বাউফল", "দশমিনা", "গলাচিপা", "কলাপাড়া", "মির্জাগঞ্জ", "রাঙ্গাবালী"],
        "পিরোজপুর": ["পিরোজপুর সদর", "ভান্ডারিয়া", "কাউখালী", "মঠবাড়িয়া", "নাজিরপুর", "নেছারাবাদ", "জিয়ানগর"],
    },
    "রংপুর": {
        "রংপুর": ["রংপুর সদর", "বদরগঞ্জ", "গঙ্গাচড়া", "কাউনিয়া", "মিঠাপুকুর", "পীরগঞ্জ", "পীরগাছা", "তারাগঞ্জ"],
        "দিনাজপুর": ["দিনাজপুর সদর", "বীরগঞ্জ", "বোচাগঞ্জ", "চিরিরবন্দর", "ঘোড়াঘাট", "হাকিমপুর", "কাহারোল"],
        "গাইবান্ধা": ["গাইবান্ধা সদর", "ফুলছড়ি", "গোবিন্দগঞ্জ", "পলাশবাড়ী", "সাদুল্লাপুর", "সাঘাটা", "সুন্দরগঞ্জ"],
        "কুড়িগ্রাম": ["কুড়িগ্রাম সদর", "ভুরুঙ্গামারী", "চিলমারী", "ফুলবাড়ী", "নাগেশ্বরী", "রাজারহাট", "রৌমারী", "উলিপুর"],
        "নীলফামারী": ["নীলফামারী সদর", "ডিমলা", "ডোমার", "জলঢাকা", "কিশোরগঞ্জ", "সৈয়দপুর"],
        "লালমনিরহাট": ["লালমনিরহাট সদর", "আদিতমারী", "হাতীবান্ধা", "কালীগঞ্জ", "পাটগ্রাম"],
        "পঞ্চগড়": ["পঞ্চগড় সদর", "আটোয়ারী", "বোদা", "দেবীগঞ্জ", "তেঁতুলিয়া"],
        "ঠাকুরগাঁও": ["ঠাকুরগাঁও সদর", "বালিয়াডাঙ্গী", "হরিপুর", "পীরগঞ্জ", "রাণীশংকৈল"],
    },
    "ময়মনসিংহ": {
        "ময়মনসিংহ": ["ময়মনসিংহ সদর", "ভালুকা", "ধোবাউড়া", "ফুলবাড়িয়া", "গফরগাঁও", "গৌরীপুর", "হালুয়াঘাট"],
        "নেত্রকোণা": ["নেত্রকোণা সদর", "আটপাড়া", "বারহাট্টা", "দুর্গাপুর", "খালিয়াজুরী", "কলমাকান্দা"],
        "জামালপুর": ["জামালপুর সদর", "বকশীগঞ্জ", "দেওয়ানগঞ্জ", "ইসলামপুর", "মাদারগঞ্জ", "মেলান্দহ", "সরিষাবাড়ী"],
        "শেরপুর": ["শেরপুর সদর", "ঝিনাইগাতী", "নালিতাবাড়ী", "নকলা", "শ্রীবরদী"],
    },
    "সিলেট": {
        "সিলেট": ["সিলেট সদর", "বালাগঞ্জ", "বিয়ানীবাজার", "বিশ্বনাথ", "কোম্পানীগঞ্জ", "ফেঞ্চুগঞ্জ", "গোয়াইনঘাট"],
        "মৌলভীবাজার": ["মৌলভীবাজার সদর", "বড়লেখা", "জুড়ী", "কমলগঞ্জ", "কুলাউড়া", "রাজনগর", "শ্রীমঙ্গল"],
        "হবিগঞ্জ": ["হবিগঞ্জ সদর", "আজমিরীগঞ্জ", "বাহুবল", "বানিয়াচং", "চুনারুঘাট", "লাখাই", "মাধবপুর", "নবীগঞ্জ"],
        "সুনামগঞ্জ": ["সুনামগঞ্জ সদর", "ছাতক", "দক্ষিণ সুনামগঞ্জ", "দিরাই", "ধর্মপাশা", "দোয়ারাবাজার", "জগন্নাথপুর"],
    },
}


class PDFTextExtractor:
    """PDF থেকে বাংলা টেক্সট এক্সট্র্যাক্ট করার ক্লাস"""

    def __init__(self):
        self.stats = {"success": 0, "failed": 0, "total_pages": 0}

    def extract_with_pymupdf(self, pdf_path: str) -> str:
        """PyMuPDF দিয়ে টেক্সট এক্সট্র্যাক্ট (বাংলার জন্য সবচেয়ে ভালো)"""
        try:
            doc = fitz.open(pdf_path)
            full_text = []

            for page_num in range(len(doc)):
                page = doc[page_num]
                # বাংলা unicode সঠিকভাবে পড়ার জন্য
                text = page.get_text("text", sort=True)  # sort=True: reading order অনুযায়ী
                if text.strip():
                    full_text.append(text)
                self.stats["total_pages"] += 1

            doc.close()
            return "\n".join(full_text)
        except Exception as e:
            logger.warning(f"PyMuPDF ব্যর্থ ({pdf_path}): {e}")
            return ""

    def extract_with_pdfplumber(self, pdf_path: str) -> str:
        """pdfplumber দিয়ে টেক্সট এক্সট্র্যাক্ট (ফলব্যাক)"""
        try:
            with pdfplumber.open(pdf_path) as pdf:
                full_text = []
                for page in pdf.pages:
                    text = page.extract_text(x_tolerance=3, y_tolerance=3)
                    if text:
                        full_text.append(text)
            return "\n".join(full_text)
        except Exception as e:
            logger.warning(f"pdfplumber ব্যর্থ ({pdf_path}): {e}")
            return ""

    def extract_text(self, pdf_path: str) -> str:
        """সর্বোত্তম পদ্ধতিতে টেক্সট এক্সট্র্যাক্ট করে"""
        # প্রথমে PyMuPDF চেষ্টা করে
        text = self.extract_with_pymupdf(pdf_path)

        # যদি কাজ না করে, pdfplumber চেষ্টা করে
        if not text or len(text.strip()) < 50:
            logger.info(f"pdfplumber দিয়ে চেষ্টা করছি: {pdf_path}")
            text = self.extract_with_pdfplumber(pdf_path)

        if text:
            text = self.clean_text(text)
            self.stats["success"] += 1
        else:
            self.stats["failed"] += 1
            logger.error(f"টেক্সট এক্সট্র্যাক্ট করা যায়নি: {pdf_path}")

        return text

    def clean_text(self, text: str) -> str:
        """বাংলা টেক্সট পরিষ্কার করে"""
        if not text:
            return ""

        # অতিরিক্ত whitespace সরানো (কিন্তু নতুন লাইন রাখা)
        lines = text.split('\n')
        cleaned_lines = []

        for line in lines:
            # লাইনের শুরু ও শেষের space সরানো
            line = line.strip()

            # একাধিক space কে একটিতে পরিণত করা
            line = re.sub(r'[ \t]+', ' ', line)

            # খালি লাইন বাদ দেওয়া (কিন্তু দুটো খালি লাইন একটিতে রাখা)
            if line:
                cleaned_lines.append(line)
            elif cleaned_lines and cleaned_lines[-1] != '':
                cleaned_lines.append('')

        # শেষের খালি লাইন সরানো
        while cleaned_lines and cleaned_lines[-1] == '':
            cleaned_lines.pop()

        return '\n'.join(cleaned_lines)


class LocationDetector:
    """বিভাগ, জেলা, উপজেলা সনাক্ত করার ক্লাস"""

    def __init__(self):
        # দ্রুত সার্চের জন্য রিভার্স ম্যাপ তৈরি
        self.upazila_to_district = {}
        self.district_to_division = {}

        for division, districts in BANGLADESH_LOCATIONS.items():
            for district, upazilas in districts.items():
                self.district_to_division[district] = division
                for upazila in upazilas:
                    self.upazila_to_district[upazila] = (district, division)

    def detect_from_filename(self, filename: str) -> dict:
        """ফাইলের নাম থেকে লোকেশন বের করে"""
        result = {"division": None, "district": None, "upazila": None}

        # ফাইলনেম থেকে আন্ডারস্কোর/হাইফেন সরিয়ে পড়া
        name = Path(filename).stem.replace('_', ' ').replace('-', ' ')

        # বিভাগ খোঁজা
        for division in BANGLADESH_LOCATIONS.keys():
            if division in name:
                result["division"] = division
                break

        # জেলা খোঁজা
        for district in self.district_to_division.keys():
            if district in name:
                result["district"] = district
                result["division"] = self.district_to_division[district]
                break

        # উপজেলা খোঁজা
        for upazila, (district, division) in self.upazila_to_district.items():
            if upazila in name:
                result["upazila"] = upazila
                result["district"] = district
                result["division"] = division
                break

        return result

    def detect_from_text(self, text: str) -> dict:
        """টেক্সটের প্রথম অংশ থেকে লোকেশন বের করে"""
        result = {"division": None, "district": None, "upazila": None}

        # প্রথম ৫০০ অক্ষর এবং শেষের ২০০ অক্ষরে খোঁজা
        search_text = text[:500] + "\n" + text[-200:] if len(text) > 700 else text

        # বিভাগ খোঁজা
        for division in BANGLADESH_LOCATIONS.keys():
            if division in search_text:
                result["division"] = division

        # উপজেলা খোঁজা (উপজেলা পেলে জেলা ও বিভাগ স্বয়ংক্রিয়)
        for upazila, (district, division) in self.upazila_to_district.items():
            if upazila in search_text:
                result["upazila"] = upazila
                result["district"] = district
                result["division"] = division
                break

        # জেলা খোঁজা (উপজেলা না পেলে)
        if not result["district"]:
            for district, division in self.district_to_division.items():
                if district in search_text:
                    result["district"] = district
                    result["division"] = division
                    break

        return result

    def detect(self, filename: str, text: str) -> dict:
        """ফাইলনেম এবং টেক্সট উভয় থেকে লোকেশন বের করে"""
        from_name = self.detect_from_filename(filename)
        from_text = self.detect_from_text(text)

        # ফাইলনেম এবং টেক্সট উভয়ের ফলাফল মেলানো
        result = {
            "division": from_name.get("division") or from_text.get("division"),
            "district": from_name.get("district") or from_text.get("district"),
            "upazila": from_name.get("upazila") or from_text.get("upazila"),
        }

        return result


class DatabaseManager:
    """SQLite ডেটাবেজ ম্যানেজার"""

    def __init__(self, db_path: str = "pdf_database.db"):
        self.db_path = db_path
        self.conn = None
        self.connect()
        self.create_tables()
        self.create_indexes()

    def connect(self):
        """ডেটাবেজ কানেকশন তৈরি"""
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute("PRAGMA journal_mode=WAL")  # দ্রুত লেখার জন্য
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA cache_size=10000")
        self.conn.row_factory = sqlite3.Row  # dict-like access
        logger.info(f"ডেটাবেজ সংযুক্ত: {self.db_path}")

    def create_tables(self):
        """টেবিল তৈরি করা"""
        cursor = self.conn.cursor()

        # মূল ডকুমেন্ট টেবিল
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                zip_file TEXT NOT NULL,
                pdf_filename TEXT NOT NULL,
                division TEXT,
                district TEXT,
                upazila TEXT,
                content TEXT NOT NULL,
                page_count INTEGER DEFAULT 0,
                word_count INTEGER DEFAULT 0,
                char_count INTEGER DEFAULT 0,
                extraction_date TEXT NOT NULL,
                status TEXT DEFAULT 'processed',
                UNIQUE(zip_file, pdf_filename)
            )
        """)

        # FTS (Full Text Search) ভার্চুয়াল টেবিল - দ্রুত সার্চের জন্য
        cursor.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts
            USING fts5(
                id UNINDEXED,
                division,
                district,
                upazila,
                pdf_filename,
                content,
                content='documents',
                content_rowid='id',
                tokenize='unicode61'
            )
        """)

        # স্ট্যাটিস্টিক্স টেবিল
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS extraction_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                zip_file TEXT NOT NULL,
                total_pdfs INTEGER DEFAULT 0,
                successful INTEGER DEFAULT 0,
                failed INTEGER DEFAULT 0,
                processed_at TEXT NOT NULL
            )
        """)

        # এরর লগ টেবিল
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS error_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                zip_file TEXT,
                pdf_filename TEXT,
                error_message TEXT,
                logged_at TEXT NOT NULL
            )
        """)

        self.conn.commit()
        logger.info("টেবিল তৈরি সম্পন্ন")

    def create_indexes(self):
        """দ্রুত সার্চের জন্য ইনডেক্স তৈরি"""
        cursor = self.conn.cursor()

        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_division ON documents(division)",
            "CREATE INDEX IF NOT EXISTS idx_district ON documents(district)",
            "CREATE INDEX IF NOT EXISTS idx_upazila ON documents(upazila)",
            "CREATE INDEX IF NOT EXISTS idx_zip_file ON documents(zip_file)",
            "CREATE INDEX IF NOT EXISTS idx_division_district ON documents(division, district)",
            "CREATE INDEX IF NOT EXISTS idx_division_district_upazila ON documents(division, district, upazila)",
        ]

        for idx in indexes:
            cursor.execute(idx)

        self.conn.commit()
        logger.info("ইনডেক্স তৈরি সম্পন্ন")

    def insert_document(self, data: dict) -> int:
        """ডকুমেন্ট ইনসার্ট করা"""
        cursor = self.conn.cursor()

        try:
            cursor.execute("""
                INSERT OR REPLACE INTO documents
                (zip_file, pdf_filename, division, district, upazila,
                 content, page_count, word_count, char_count, extraction_date, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                data["zip_file"],
                data["pdf_filename"],
                data.get("division"),
                data.get("district"),
                data.get("upazila"),
                data["content"],
                data.get("page_count", 0),
                data.get("word_count", 0),
                data.get("char_count", 0),
                data.get("extraction_date", datetime.now().isoformat()),
                "processed"
            ))

            doc_id = cursor.lastrowid

            # FTS টেবিলে ইনসার্ট
            cursor.execute("""
                INSERT OR REPLACE INTO documents_fts
                (id, division, district, upazila, pdf_filename, content)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                doc_id,
                data.get("division", ""),
                data.get("district", ""),
                data.get("upazila", ""),
                data["pdf_filename"],
                data["content"]
            ))

            self.conn.commit()
            return doc_id

        except Exception as e:
            self.conn.rollback()
            logger.error(f"ডেটা ইনসার্ট ব্যর্থ: {e}")
            raise

    def log_error(self, zip_file: str, pdf_filename: str, error: str):
        """এরর লগ করা"""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO error_log (zip_file, pdf_filename, error_message, logged_at)
            VALUES (?, ?, ?, ?)
        """, (zip_file, pdf_filename, error, datetime.now().isoformat()))
        self.conn.commit()

    def save_stats(self, zip_file: str, total: int, success: int, failed: int):
        """স্ট্যাটস সেভ করা"""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO extraction_stats
            (zip_file, total_pdfs, successful, failed, processed_at)
            VALUES (?, ?, ?, ?, ?)
        """, (zip_file, total, success, failed, datetime.now().isoformat()))
        self.conn.commit()

    def rebuild_fts(self):
        """FTS ইনডেক্স পুনর্নির্মাণ"""
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO documents_fts(documents_fts) VALUES('rebuild')")
        self.conn.commit()
        logger.info("FTS ইনডেক্স পুনর্নির্মাণ সম্পন্ন")

    def close(self):
        """কানেকশন বন্ধ করা"""
        if self.conn:
            self.conn.close()


class ZipPDFProcessor:
    """ZIP ফাইল থেকে PDF প্রসেস করার মূল ক্লাস"""

    def __init__(self, db_path: str = "pdf_database.db"):
        self.extractor = PDFTextExtractor()
        self.detector = LocationDetector()
        self.db = DatabaseManager(db_path)
        self.temp_dir = Path("temp_pdfs")
        self.temp_dir.mkdir(exist_ok=True)

    def count_words(self, text: str) -> int:
        """বাংলা ও ইংরেজি শব্দ গণনা"""
        # বাংলা ও ইংরেজি উভয় শব্দ গণনা
        words = re.findall(r'[\u0980-\u09FF]+|[a-zA-Z]+', text)
        return len(words)

    def process_pdf(self, pdf_path: str, zip_filename: str, pdf_name: str) -> bool:
        """একটি PDF প্রসেস করা"""
        try:
            logger.info(f"  প্রসেস করছি: {pdf_name}")

            # টেক্সট এক্সট্র্যাক্ট
            text = self.extractor.extract_text(pdf_path)

            if not text or len(text.strip()) < 10:
                logger.warning(f"  টেক্সট পাওয়া যায়নি: {pdf_name}")
                self.db.log_error(zip_filename, pdf_name, "No text extracted")
                return False

            # লোকেশন সনাক্ত
            location = self.detector.detect(pdf_name, text)

            # পেজ সংখ্যা গণনা
            try:
                doc = fitz.open(pdf_path)
                page_count = len(doc)
                doc.close()
            except:
                page_count = 0

            # ডেটাবেজে সেভ
            data = {
                "zip_file": zip_filename,
                "pdf_filename": pdf_name,
                "division": location.get("division"),
                "district": location.get("district"),
                "upazila": location.get("upazila"),
                "content": text,
                "page_count": page_count,
                "word_count": self.count_words(text),
                "char_count": len(text),
                "extraction_date": datetime.now().isoformat(),
            }

            doc_id = self.db.insert_document(data)
            logger.info(f"  ✓ সেভ হয়েছে (ID: {doc_id}) | "
                       f"বিভাগ: {location.get('division', 'অজানা')} | "
                       f"জেলা: {location.get('district', 'অজানা')} | "
                       f"উপজেলা: {location.get('upazila', 'অজানা')}")
            return True

        except Exception as e:
            logger.error(f"  ✗ ব্যর্থ ({pdf_name}): {e}")
            self.db.log_error(zip_filename, pdf_name, str(e))
            return False

    def process_zip(self, zip_path: str) -> dict:
        """একটি ZIP ফাইল প্রসেস করা"""
        zip_filename = Path(zip_path).name
        logger.info(f"\n{'='*60}")
        logger.info(f"ZIP প্রসেস শুরু: {zip_filename}")
        logger.info(f"{'='*60}")

        stats = {"total": 0, "success": 0, "failed": 0}

        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                # সব PDF ফাইল খোঁজা
                pdf_files = [f for f in zf.namelist()
                           if f.lower().endswith('.pdf') and not f.startswith('__MACOSX')]

                logger.info(f"মোট PDF পাওয়া গেছে: {len(pdf_files)}")
                stats["total"] = len(pdf_files)

                for i, pdf_name in enumerate(pdf_files, 1):
                    logger.info(f"\n[{i}/{len(pdf_files)}] {pdf_name}")

                    # PDF এক্সট্র্যাক্ট করা
                    temp_pdf = self.temp_dir / f"temp_{i}_{Path(pdf_name).name}"

                    try:
                        # ZIP থেকে টেম্প ফোল্ডারে বের করা
                        with zf.open(pdf_name) as source:
                            with open(temp_pdf, 'wb') as target:
                                target.write(source.read())

                        # প্রসেস করা
                        success = self.process_pdf(
                            str(temp_pdf),
                            zip_filename,
                            Path(pdf_name).name
                        )

                        if success:
                            stats["success"] += 1
                        else:
                            stats["failed"] += 1

                    finally:
                        # টেম্প ফাইল মুছে ফেলা
                        if temp_pdf.exists():
                            temp_pdf.unlink()

        except zipfile.BadZipFile:
            logger.error(f"অবৈধ ZIP ফাইল: {zip_path}")
            stats["failed"] = stats["total"]
        except Exception as e:
            logger.error(f"ZIP প্রসেস ব্যর্থ: {e}")

        # স্ট্যাটস সেভ
        self.db.save_stats(zip_filename, stats["total"], stats["success"], stats["failed"])

        logger.info(f"\n{zip_filename} সম্পন্ন:")
        logger.info(f"  মোট: {stats['total']} | সফল: {stats['success']} | ব্যর্থ: {stats['failed']}")

        return stats

    def process_multiple_zips(self, zip_folder: str) -> None:
        """একটি ফোল্ডারের সব ZIP ফাইল প্রসেস করা"""
        zip_folder = Path(zip_folder)
        zip_files = list(zip_folder.glob("*.zip"))

        if not zip_files:
            logger.warning(f"কোন ZIP ফাইল পাওয়া যায়নি: {zip_folder}")
            return

        logger.info(f"মোট ZIP ফাইল পাওয়া গেছে: {len(zip_files)}")

        total_stats = {"total": 0, "success": 0, "failed": 0}

        for i, zip_path in enumerate(zip_files, 1):
            logger.info(f"\n[ZIP {i}/{len(zip_files)}] {zip_path.name}")
            stats = self.process_zip(str(zip_path))

            total_stats["total"] += stats["total"]
            total_stats["success"] += stats["success"]
            total_stats["failed"] += stats["failed"]

        # FTS পুনর্নির্মাণ
        logger.info("\nFTS ইনডেক্স আপডেট করছি...")
        self.db.rebuild_fts()

        logger.info(f"\n{'='*60}")
        logger.info("সব ZIP প্রসেস সম্পন্ন!")
        logger.info(f"মোট PDF: {total_stats['total']}")
        logger.info(f"সফল: {total_stats['success']}")
        logger.info(f"ব্যর্থ: {total_stats['failed']}")
        logger.info(f"{'='*60}")

    def cleanup(self):
        """টেম্প ফাইল মুছে ফেলা"""
        import shutil
        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
        self.db.close()


# ========== মূল প্রোগ্রাম ==========
if __name__ == "__main__":
    import sys

    print("=" * 60)
    print("PDF → ডেটাবেজ সিস্টেম (বাংলা সমর্থিত)")
    print("=" * 60)

    if len(sys.argv) < 2:
        print("\nব্যবহার:")
        print("  একটি ZIP:     python pdf_extractor.py myfile.zip")
        print("  একটি ফোল্ডার: python pdf_extractor.py /path/to/zip/folder")
        print("\nউদাহরণ:")
        print("  python pdf_extractor.py documents.zip")
        print("  python pdf_extractor.py ./zip_files/")
        sys.exit(1)

    input_path = sys.argv[1]
    db_path = sys.argv[2] if len(sys.argv) > 2 else "pdf_database.db"

    processor = ZipPDFProcessor(db_path=db_path)

    try:
        path = Path(input_path)

        if path.is_file() and path.suffix.lower() == '.zip':
            # একটি ZIP ফাইল প্রসেস
            processor.process_zip(str(path))
        elif path.is_dir():
            # ফোল্ডারের সব ZIP প্রসেস
            processor.process_multiple_zips(str(path))
        else:
            print(f"অবৈধ ইনপুট: {input_path}")
            sys.exit(1)

    finally:
        processor.cleanup()
        print(f"\nডেটাবেজ সেভ হয়েছে: {db_path}")
        print("সার্চের জন্য search_tool.py ব্যবহার করুন")
